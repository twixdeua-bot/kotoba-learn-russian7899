package com.nexo.kotoba

/**
 * Speak text in the learner's current target language (the "learning" language),
 * or in English when [targetAudio] is false.
 */
fun speak(store: Store, speaker: Speaker, text: String, targetAudio: Boolean) {
    speaker.setRate(store.speechRate)
    speaker.speak(text, if (targetAudio) store.target else "en")
}

/** Speak text in one explicit language, ignoring the current target. */
fun speakIn(store: Store, speaker: Speaker, text: String, lang: String) {
    speaker.setRate(store.speechRate)
    speaker.speak(text, lang)
}

fun localeFor(code: String): String = when (code) {
    "ja" -> "ja-JP"
    "hi" -> "hi-IN"
    "es" -> "es-ES"
    "ar" -> "ar-SA"
    "fr" -> "fr-FR"
    "de" -> "de-DE"
    "bn" -> "bn-IN"
    "ta" -> "ta-IN"
    "te" -> "te-IN"
    "ur" -> "ur-PK"
    "kn" -> "kn-IN"
    "ru" -> "ru-RU"
    else -> "en-US"
}

/**
 * Trim a dictionary gloss down to its first, most common sense, dropping leading
 * sense numbers and everything after the first `;`.
 */
fun cleanGloss(raw: String?): String? {
    if (raw.isNullOrBlank()) return null
    var s = raw.substringBefore(';').trim()
    s = s.replace(Regex("^\\(?\\d+[.)]\\s*"), "").trim()
    return s.ifEmpty { null }
}

fun Word.glossFor(native: String): String {
    if (lang != "ja" && lang != "en") {
        val m = nativeMeaning(en, en, native)
        return cleanGloss(m) ?: m
    }
    return when (native) {
        "ja" -> if (kana.isNotEmpty()) kana + (if (romaji.isNotEmpty()) " ($romaji)" else "") else nativeMeaning(en, en, native)
        "hi" -> if (hi.isNotEmpty()) hi else nativeMeaning(en, en, native)
        else -> nativeMeaning(en, en, native)
    }
}

fun Phrase.glossFor(native: String): String = when (native) {
    "ja" -> ja
    "hi" -> if (hi.isNotEmpty()) hi else nativeMeaning(en, en, native)
    else -> nativeMeaning(en, en, native)
}

fun russianPatternTitle(title: String): String {
    val t = title
    val map = mapOf(
        "～ば — 'if ~ (then)'" to "～ば — условие «если…»",
        "～て しまう — 'end up ~ (regretfully)'" to "～てしまう — завершённость / сожаление",
        "～ために — 'in order to ~' / 'because of ~'" to "～ために — «для того чтобы…» / «из-за…»",
        "～はず — 'supposed to ~'" to "～はず — «должен / предполагается»",
        "～ようになる — 'come to ~ (gradually)'" to "～ようになる — постепенное изменение",
        "Passive — ～られる" to "Пассив — ～られる",
        "～て いく / ～て くる — going on / coming along" to "～ていく / ～てくる — изменение во времени",
        "～ばかり — 'nothing but ~ / just did ~'" to "～ばかり — «только / только что»",
        "～ことに — 'to my ~ (surprise/sadness)'" to "～ことに — реакция говорящего",
        "～ことに している — 'make a rule to ~'" to "～ことにしている — личное правило",
        "～を 問わず — 'regardless of ~'" to "～を問わず — независимо от…",
        "～に 限らず — 'not limited to ~'" to "～に限らず — не ограничиваясь…",
        "～に したがって / ～に つれて — 'as ~'" to "～にしたがって / ～につれて — по мере того как…",
        "～上で / ～上は — 'in terms of ~ / given ~'" to "～上で / ～上は — с точки зрения / раз уж…",
        "～として — 'as ~'" to "～として — в качестве…",
        "～に とって — 'for ~ (from ~'s perspective)'" to "～にとって — для / с точки зрения…",
        "～に関して — 'regarding ~'" to "～に関して — относительно…",
        "～ばかりか — 'not only ~ but also'" to "～ばかりか — не только…, но и…",
        "～た ことが あります — 'have done ~ before'" to "～たことがあります — опыт",
        "～ては いけません — 'must not ~'" to "～てはいけません — запрет",
        "～なくても いいです — 'don't have to ~'" to "～なくてもいいです — необязательно",
        "Potential — ～ことが できます / ～られます" to "Возможность — ～ことができます / ～られます",
        "～ながら — 'while doing ~'" to "～ながら — одновременно выполняя…",
        "～つもり — 'I intend to ~'" to "～つもり — намерение",
        "～そうです — 'looks like ~'" to "～そうです — «похоже, что…»",
        "～たら — 'if / when ~'" to "～たら — условие / «когда…»",
        "～て あげる / くれる / もらう — giving & receiving" to "～てあげる / くれる / もらう — давать и получать услуги",
        "～やすい / にくい — 'easy to ~ / hard to ~'" to "～やすい / にくい — легко / трудно сделать",
        "です / ます — polite endings" to "です / ます — вежливые окончания",
        "は — topic marker" to "は — частица темы",
        "が — subject marker" to "が — частица подлежащего",
        "を — object marker" to "を — частица объекта",
        "に — time & destination" to "に — время и направление",
        "で — place of action & means" to "で — место действия и средство",
        "へ — direction" to "へ — направление",
        "と — with / together with" to "と — с / вместе с",
        "の — possession" to "の — принадлежность",
        "て-form — connecting & requesting" to "Форма て — соединение и просьбы",
        "ない-form — negatives" to "Форма ない — отрицание",
        "た-form — past tense" to "Форма た — прошедшее время",
        "〜ている — ongoing actions & states" to "〜ている — процесс и состояние",
        "potential — can do (〜られる / 〜える)" to "Потенциальная форма — мочь сделать",
        "〜たい — want to" to "〜たい — хотеть сделать",
        "〜てください — please do" to "〜てください — просьба",
        "〜ましょう — let's / shall we" to "〜ましょう — «давайте…»",
        "conditionals — ば / たら / と" to "Условия — ば / たら / と",
        "comparison — より & いちばん" to "Сравнение — より и いちばん",
        "counters — counting things" to "Счётные слова",
        "～を 皮切りに — 'starting with ~'" to "～を皮切りに — начиная с…",
        "～に 至って — 'only now (finally)'" to "～に至って — только теперь",
        "～ずには いられない — 'can't help but ~'" to "～ずにはいられない — «не могу не…»",
        "～とは いえ — 'although / granted that'" to "～とはいえ — хотя / тем не менее",
        "～が 最後 — 'once ~, then it's over'" to "～が最後 — стоит только…, как…",
        "～んばかり — 'as if about to / as good as'" to "～んばかり — словно вот-вот…",
        "～ともあろう — 'a person of the caliber of ~'" to "～ともあろう — такой человек, как…",
        "～まじき — 'unbecoming of / not fit for'" to "～まじき — недостойный / неподобающий",
        "～を ください — 'please give me ~'" to "～をください — «дайте мне, пожалуйста…»",
        "～に あります / います — location of things" to "～にあります / います — местонахождение",
        "～が あります — 'I have ~'" to "～があります — наличие / «у меня есть…»",
        "い-adjective past — ～かったです" to "Прошедшее い-прилагательных — ～かったです",
        "～ましょうか — 'shall I ~?'" to "～ましょうか — предложение / «может, я…?»",
        "もう / まだ — 'already' and 'not yet'" to "もう / まだ — «уже» и «ещё / пока не»",
        "～と いっしょに — 'together with ~'" to "～といっしょに — вместе с…",
        "～を おねがいします — 'I'd like ~ (please)'" to "～をお願いします — вежливая просьба / заказ"
    )
    return map[t] ?: t
}

private val RUSSIAN_JAPANESE_RULES = mapOf(
    "～ば — 'if ~ (then)'" to "Условие: «если…, то…». Образуется с помощью формы 〜ば.",
    "～て しまう — 'end up ~ (regretfully)'" to "Выражает завершённость действия или сожаление о результате: «взять и…», «случайно…», «полностью…».",
    "～ために — 'in order to ~' / 'because of ~'" to "ために означает «для того чтобы…» или «из-за / вследствие…» в зависимости от контекста.",
    "～はず — 'supposed to ~'" to "はず выражает ожидание или уверенность: «должен…», «предполагается, что…».",
    "～ようになる — 'come to ~ (gradually)'" to "ようになる показывает постепенное изменение состояния или способности: «начать…», «стать способным…».",
    "Passive — ～られる" to "Пассив: действие направлено на предмет или человека. 〜られる также используется для некоторых других значений, поэтому важен контекст.",
    "～て いく / ～て くる — going on / coming along" to "ていく показывает движение или изменение от настоящего в будущее; てくる — изменение, приближающееся к настоящему.",
    "～ばかり — 'nothing but ~ / just did ~'" to "ばかり может означать «только», «ничего кроме…», а с формой た — «только что…».",
    "～ことに — 'to my ~ (surprise/sadness)'" to "ことに используется в конструкциях вроде «к моему удивлению», «к сожалению» и подчёркивает реакцию говорящего.",
    "～ことに している — 'make a rule to ~'" to "ことにしている означает личное правило или привычку: «я решил(а) всегда…», «я стараюсь…».",
    "～を 問わず — 'regardless of ~'" to "を問わず означает «независимо от…», «не считая различий в…».",
    "～に 限らず — 'not limited to ~'" to "に限らず означает «не ограничиваясь…», «не только…».",
    "～に したがって / ～に つれて — 'as ~'" to "Эти конструкции показывают параллельное изменение: «по мере того как…», «с увеличением…».",
    "～上で / ～上は — 'in terms of ~ / given ~'" to "上で означает «с точки зрения / после того как…», а 上は — «раз уж…, при данных обстоятельствах…».",
    "～として — 'as ~'" to "として означает роль или статус: «в качестве…», «как…».",
    "～に とって — 'for ~ (from ~'s perspective)'" to "にとって показывает, для кого или с чьей точки зрения что-то важно: «для…», «с точки зрения…».",
    "～に関して — 'regarding ~'" to "に関して означает «касательно…», «относительно…», «по поводу…».",
    "～ばかりか — 'not only ~ but also'" to "ばかりか означает «не только…, но и…».",
    "～た ことが あります — 'have done ~ before'" to "たことがあります означает опыт: «когда-либо делал…», «мне доводилось…».",
    "～ては いけません — 'must not ~'" to "てはいけません — запрет: «нельзя…», «не следует…».",
    "～なくても いいです — 'don't have to ~'" to "なくてもいいです означает отсутствие необходимости: «не обязательно…», «можно не…».",
    "Potential — ～ことが できます / ～られます" to "Потенциальная форма выражает возможность: «могу сделать…», «умею…». Используются ことができます или потенциальная форма глагола.",
    "～ながら — 'while doing ~'" to "ながら соединяет одновременные действия: «делая…, одновременно…».",
    "～つもり — 'I intend to ~'" to "つもり выражает намерение или план: «собираюсь…», «намерен…».",
    "～そうです — 'looks like ~'" to "そうです может показывать впечатление по внешнему виду: «похоже, что…», «выглядит так, будто…».",
    "～たら — 'if / when ~'" to "たら используется для условия или момента: «если…», «когда…», «после того как…».",
    "～て あげる / くれる / もらう — giving & receiving" to "Эти формы описывают передачу действия или услуги: あげる — сделать для другого, くれる — сделать для говорящего, もらう — получить услугу.",
    "～やすい / にくい — 'easy to ~ / hard to ~'" to "やすい и にくい присоединяются к основе глагола и означают «легко сделать» и «трудно сделать».",
    "です / ます — polite endings" to "です и ます — основные вежливые окончания. です употребляется с существительными и прилагательными, ます — с глаголами.",
    "は — topic marker" to "は обозначает тему высказывания: «что касается…», «а вот…».",
    "が — subject marker" to "が отмечает подлежащее или выделяет информацию как новую/важную.",
    "を — object marker" to "を отмечает прямое дополнение — то, на что направлено действие.",
    "に — time & destination" to "に отмечает конкретное время, пункт назначения или точку, к которой относится действие.",
    "で — place of action & means" to "で показывает место совершения действия или средство/способ: «в…», «с помощью…».",
    "へ — direction" to "へ показывает направление движения: «в сторону…», «к…».",
    "と — with / together with" to "と используется для значения «с», «вместе с», а также при цитировании.",
    "の — possession" to "の связывает существительные и часто выражает принадлежность: «X из Y», «X-ов», «принадлежащий X».",
    "て-form — connecting & requesting" to "Форма て используется для соединения действий, просьб, разрешений и других конструкций.",
    "ない-form — negatives" to "Форма ない образует отрицание глагола в простой форме: «не делать…».",
    "た-form — past tense" to "Форма た — прошедшее время в простой форме и часть нескольких грамматических конструкций.",
    "〜ている — ongoing actions & states" to "ている показывает действие в процессе или состояние, являющееся результатом действия.",
    "potential — can do (〜られる / 〜える)" to "Потенциальная форма означает возможность или способность: «мочь…», «уметь…».",
    "〜たい — want to" to "たい присоединяется к основе глагола и означает желание: «хочу…».",
    "〜てください — please do" to "てください — вежливая просьба: «пожалуйста, сделайте…».",
    "〜ましょう — let's / shall we" to "ましょう выражает предложение сделать что-то вместе: «давайте…», «будем…».",
    "conditionals — ば / たら / と" to "Основные условные конструкции японского: ば, たら и と. Выбор зависит от смысла и типа условия.",
    "comparison — より & いちばん" to "より используется для сравнения «более…, чем…», а いちばん — для превосходной степени «самый…».",
    "counters — counting things" to "Японские счётные слова используются вместе с числительными и зависят от типа предмета: людей, книг, длинных предметов и т. д.",
    "～を 皮切りに — 'starting with ~'" to "を皮切りに означает «начиная с…», подчёркивая отправную точку последовательности событий.",
    "～に 至って — 'only now (finally)'" to "に至って означает «только теперь», «дойдя до этого этапа», подчёркивая поздний результат.",
    "～ずには いられない — 'can't help but ~'" to "ずにはいられない означает невозможность удержаться от действия: «не могу не…».",
    "～とは いえ — 'although / granted that'" to "とはいえ означает «хотя…», «пусть даже…», «тем не менее…».",
    "～が 最後 — 'once ~, then it's over'" to "が最後 означает, что после одного события неизбежно происходит другое: «стоит только…, как…».",
    "～んばかり — 'as if about to / as good as'" to "んばかり означает «словно вот-вот…», «как будто почти…».",
    "～ともあろう — 'a person of the caliber of ~'" to "ともあろう подчёркивает ожидания от человека с определённым статусом: «такой человек, как…».",
    "～まじき — 'unbecoming of / not fit for'" to "まじき означает «недостойный», «неподобающий» для человека с определённой ролью.",
    "～を ください — 'please give me ~'" to "をください — вежливая просьба дать предмет: «пожалуйста, дайте мне…».",
    "～に あります / います — location of things" to "あります используется для неодушевлённых предметов, います — для людей и животных: «находится / есть…».",
    "～が あります — 'I have ~'" to "があります означает наличие или существование: «есть…», «у меня есть…».",
    "い-adjective past — ～かったです" to "Прошедшая форма い-прилагательных образуется заменой い на かった, обычно с です в вежливой речи.",
    "～ましょうか — 'shall I ~?'" to "ましょうか используется для предложения помощи или совместного действия: «может, я…?», «давайте…?».",
    "もう / まだ — 'already' and 'not yet'" to "もう означает «уже», а まだ — «ещё / пока ещё не» в зависимости от конструкции.",
    "～と いっしょに — 'together with ~'" to "といっしょに означает «вместе с…».",
    "～を おねがいします — 'I'd like ~ (please)'" to "をお願いします — вежливая просьба или заказ: «мне, пожалуйста…», «пожалуйста, дайте…»."
)

fun Pattern.ruleFor(native: String): String {
    if (native == "ru" && lang == "ja") {
        RUSSIAN_JAPANESE_RULES[titleEn]?.let { return it }
    }
    if (lang != "ja" && lang != "en") {
        val key = ruleEn.replace("\n", "\\n")
        return nativeMeaning(key, key, native).replace("\\n", "\n")
    }
    return when (native) {
        "ja" -> if (ruleJa.isNotEmpty()) ruleJa else ruleEn
        "hi" -> if (ruleHi.isNotEmpty()) ruleHi else ruleEn
        else -> nativeMeaning(ruleEn, ruleEn, native)
    }
}

fun PatternExample.glossFor(native: String, lang: String): String {
    val english = if (lang == "en") ja else en
    val target = if (lang == "en") en else ja
    if (lang != "ja" && lang != "en") {
        return when (native) {
            "en" -> english
            "hi" -> if (hi.isNotEmpty()) hi else nativeMeaning(english, english, native)
            else -> nativeMeaning(english, english, native)
        }
    }
    return when (native) {
        "en" -> if (lang == "en") "" else english
        "ja" -> if (lang == "ja") "" else target.ifEmpty { english }
        "hi" -> if (hi.isNotEmpty()) hi else (Gloss.lookup(english) ?: english)
        else -> if (english.isEmpty()) "" else Gloss.lookup(english) ?: ""
    }
}

fun Sentence.glossFor(native: String): String = when (native) {
    "hi" -> if (hi.isNotEmpty()) hi else nativeMeaning(en, en, native)
    else -> nativeMeaning(en, en, native)
}

fun AlphabetChar.glossFor(native: String): String = when (native) {
    "ja" -> if (kana.isNotEmpty()) "$kana — ${word.lowercase()}" else word
    "hi" -> if (hi.isNotEmpty()) "$hi — ${word.lowercase()}" else nativeMeaning(word, word, native)
    else -> nativeMeaning(word, word, native)
}

fun localizedRussianContent(text: String, native: String): String {
    if (native != "ru" || text.isBlank()) return text
    Gloss.lookup(text)?.let { return it }
    return text
        .replace(Regex("Genki Textbook 1 — vocabulary & phrases"), "Учебник Genki 1 — слова и фразы")
        .replace(Regex("Japanese From Zero"), "Japanese From Zero")
        .replace(Regex("\bLesson\b"), "Урок")
        .replace(Regex("\bwords\b"), "слов")
        .replace(Regex("\bword\b"), "слово")
        .replace(Regex("\bpatterns\b"), "конструкции")
        .replace(Regex("\bGrammar essentials\b"), "Основы грамматики")
}

val NATIVE_LANGUAGES = listOf(
    "en" to "🇺🇸 English",
    "hi" to "🇮🇳 Hindi",
    "ja" to "🇯🇵 Japanese",
    "es" to "🇪🇸 Spanish",
    "ar" to "🇸🇦 Arabic",
    "fr" to "🇫🇷 French",
    "de" to "🇩🇪 German",
    "bn" to "🇧🇩 Bengali",
    "ta" to "🇮🇳 Tamil",
    "te" to "🇮🇳 Telugu",
    "ur" to "🇵🇰 Urdu",
    "kn" to "🇮🇳 Kannada",
    "ru" to "🇷🇺 Russian"
)

fun nativeName(code: String): String =
    NATIVE_LANGUAGES.firstOrNull { it.first == code }?.second ?: "English"

fun languageLabel(code: String): String = when (code) {
    "ja" -> "Japanese"
    "en" -> "English"
    "ru" -> "Russian"
    else -> nativeName(code).substringAfter(' ', nativeName(code))
}
